<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="en">
<context>
    <name>AnalisaPendencias</name>
    <message>
        <location filename="../pendencias.py" line="154"/>
        <location filename="../pendencias.py" line="162"/>
        <location filename="../pendencias.py" line="170"/>
        <location filename="../pendencias.py" line="179"/>
        <location filename="../pendencias.py" line="188"/>
        <location filename="../pendencias.py" line="199"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="154"/>
        <source>selected patch(es) does not have both vertices</source>
        <translation>selected pipe segment(s) does not have two vertex</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="162"/>
        <source>selected patch(es) does not have name(s)</source>
        <translation>selected sewer segment(s) does not have identification name</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="170"/>
        <source>selected patch(es)  have repeated names</source>
        <translation>selected sewer segment(s) have repeated names</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="179"/>
        <source>selected patch(es)  have 0 (zero) extension</source>
        <translation>selected sewer segment(s) haven´t length</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="188"/>
        <source>selected patch(es) does not have nodes in one or two vertices</source>
        <translation>selected sewer segment(s) does not have nodes in one or two vertex</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="196"/>
        <source>Sucess</source>
        <translation>Sucess</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="196"/>
        <source>No nonconformities were found</source>
        <translation>No nonconformities were found</translation>
    </message>
    <message>
        <location filename="../pendencias.py" line="199"/>
        <source>Node layer not found</source>
        <translation>Node layer not found</translation>
    </message>
</context>
<context>
    <name>AutomaticGeometricAttributes</name>
    <message>
        <source>tooltip_EXT_FIELD_NAME</source>
        <translation type="vanished">Extension of patch</translation>
    </message>
</context>
<context>
    <name>AutomaticGeometricAttributesDialogBase</name>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="14"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="38"/>
        <source>Existing Layer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="54"/>
        <source>New Layer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="80"/>
        <source>Select a layer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="107"/>
        <source>Patch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="149"/>
        <source>Aux Pav 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="162"/>
        <source>Aux Prof I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="185"/>
        <source>End coordinate N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="218"/>
        <source>Aux 01</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="231"/>
        <source>Begin coordinate N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="244"/>
        <source>Numered Segment Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="287"/>
        <source>Aux 03</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="300"/>
        <source>Segment Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="313"/>
        <source>Begin coordinate E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="326"/>
        <source>End coordinate E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="339"/>
        <source>Aux 02</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="352"/>
        <source>Aux Pav 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="395"/>
        <source>Aux Prof F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="428"/>
        <source>Extension</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="451"/>
        <source>Aux Pos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="457"/>
        <source>Nodes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="469"/>
        <source>QE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="482"/>
        <source>Cota</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../red_basica_dialog_base.ui" line="505"/>
        <location filename="../red_basica_dialog_base.ui" line="553"/>
        <source>Name the layer</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AutomaticGeometricAttributesDockWidget</name>
    <message>
        <location filename="../ui_segment_dock.ui" line="20"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="29"/>
        <source>Name/Rename a patch</source>
        <translation>Name a Patch</translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="36"/>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="43"/>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="63"/>
        <source>Current Feature</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="86"/>
        <source>Save</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="94"/>
        <location filename="../ui_segment_dock.ui" line="127"/>
        <source>Patches</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="135"/>
        <source>Patch Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="140"/>
        <source>Nº Segs</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="145"/>
        <source>Length</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="153"/>
        <source>Total Extension</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="178"/>
        <source>Flow Rate List</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="211"/>
        <source>Refresh</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="218"/>
        <source>Flow Rate Concentrated</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="229"/>
        <source>QE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="234"/>
        <source>Ip</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="239"/>
        <source>Fp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="244"/>
        <source>TRM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="257"/>
        <source>About</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_segment_dock.ui" line="278"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;saniBID RedBasica v. 0.9b&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;This plugin help to build a sewer web plant.&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;This plugin is distributed as is, and its totally free.&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;For questions, bugs reporting and assorted infos, please feel free to contact:&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;leonazareth@gmail.com&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Concept Analysts:&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;Leonardo Porto Nazareth&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CalculaProfundidade</name>
    <message>
        <location filename="../profundidade.py" line="133"/>
        <source>Error</source>
        <translation>Last sewer segment not found</translation>
    </message>
    <message>
        <location filename="../profundidade.py" line="133"/>
        <source>End patch not found</source>
        <translation>Last sewer segment not found</translation>
    </message>
</context>
<context>
    <name>CreatePointLayerImportRaster</name>
    <message>
        <location filename="../create_pointLayer_importRaster_dialog.ui" line="14"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../create_pointLayer_importRaster_dialog.ui" line="26"/>
        <source>Name of node layer</source>
        <translation>Nodes layer name</translation>
    </message>
    <message>
        <location filename="../create_pointLayer_importRaster_dialog.ui" line="59"/>
        <source>Select the raster layer</source>
        <translation>Select the raster layer</translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../export_dialog.ui" line="14"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../export_dialog.ui" line="29"/>
        <source>Select the output file</source>
        <translation>Select the output file:</translation>
    </message>
    <message>
        <location filename="../export_dialog.ui" line="39"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../export_dialog.ui" line="49"/>
        <source>Apenas Trechos Selecionados</source>
        <translation>Only selected</translation>
    </message>
</context>
<context>
    <name>NameSegmentDialog</name>
    <message>
        <location filename="../name_segment_dialog_base.ui" line="14"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../name_segment_dialog_base.ui" line="26"/>
        <source>Name the segment:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../name_segment_dialog_base.ui" line="49"/>
        <source>Initial count</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>recobrimento_dialog</name>
    <message>
        <location filename="../recobrimento_dialog.ui" line="14"/>
        <source>saniBID RedBasica</source>
        <translation>saniBID RedBasica</translation>
    </message>
    <message>
        <location filename="../recobrimento_dialog.ui" line="45"/>
        <source>Recobrimento Mínimo [m]: </source>
        <translation>Minimum recoating depth [m]: </translation>
    </message>
    <message>
        <location filename="../recobrimento_dialog.ui" line="52"/>
        <source>Diâmetro [mm]: </source>
        <translation>Diameter [mm]: </translation>
    </message>
    <message>
        <location filename="../recobrimento_dialog.ui" line="59"/>
        <source>Declividade [m/m]: </source>
        <translation>Slope [m / m]: </translation>
    </message>
    <message>
        <location filename="../recobrimento_dialog.ui" line="66"/>
        <source>(Opcional) Profundidade Inicial [m]: </source>
        <translation>(Optional) Initial Depth [m]: </translation>
    </message>
    <message>
        <location filename="../recobrimento_dialog.ui" line="124"/>
        <source>Apenas Selecionados</source>
        <translation>Only selected</translation>
    </message>
</context>
<context>
    <name>time</name>
    <message>
        <source>Select the output file</source>
        <translation type="vanished">Select the output file:</translation>
    </message>
    <message>
        <source>A camada já existe no projeto atual.</source>
        <translation type="vanished">The layer already exists.</translation>
    </message>
</context>
</TS>
