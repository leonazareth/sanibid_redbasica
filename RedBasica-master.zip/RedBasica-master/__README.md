<html>
<body>
<h3>Automatic Geometric Attributes</h3>

<h4>What's this plugin does:</h4>
<ol>
    <li>Capture the coordinates of a line, when added or updated
    <li>Fill the attributes of a line withe the captured values
    <li>You can especify a layer to watch
    <li>You can especify the attributes you want to fill
    <li>The settings are saved on qgis project file, once saved you do not need to reconfigure nothing
    <li>When reopen a project only need to click start to watcher do the magic
</ol>

<b>Dependencies</b>
<ol>
    <li>QCad plugin
</ol>

<h3>Atributos Geométricos Automáticos</h3>
<h4>O que este plugin faz:</h4>
<ol>
    <li>Captura as coordenadas de uma linha, quando adicionada ou modificada
    <li>Preenche os atributos de uma linha com os valores capturados
    <li>Você pode especificar qual camada quer observar
    <li>Você pode especificar os atributos que quer preencher
    <li>As configurações são salvas no arquivo de projeto do QGis, uma vez salvo, não há necessidade de reconfigurar nada
    <li>Quando reabrir um projeto a única ação necessária é clicar em iniciar para o observador fazer a mágica
</ol>

<b>Dependências</b>
<ol>
    <li>Plugin QCad
</ol>

</body>
</html>
