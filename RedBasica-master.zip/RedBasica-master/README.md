<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 4.1.6.2 (Linux)">
	<META NAME="AUTHOR" CONTENT="LeoNazareth">
	<META NAME="CREATED" CONTENT="20160913;140200000000000">
	<META NAME="CHANGEDBY" CONTENT="LeoNazareth">
	<META NAME="CHANGED" CONTENT="20160916;123300000000000">
	<META NAME="AppVersion" CONTENT="14.0000">
	<META NAME="DocSecurity" CONTENT="0">
	<META NAME="HyperlinksChanged" CONTENT="false">
	<META NAME="LinksUpToDate" CONTENT="false">
	<META NAME="ScaleCrop" CONTENT="false">
	<META NAME="ShareDoc" CONTENT="false">
</HEAD>
<BODY LANG="pt-BR" DIR="LTR">
<H1 CLASS="western">Apresentação</H1>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<FONT COLOR="#000000">O plugin RedBasica foi desenvolvido com
patrocínio do BID (Banco Interamericano de Desenvolvimento – </FONT><FONT COLOR="#ff0000">Banco
Interamericano de Desarrollo</FONT><FONT COLOR="#000000">), AECID
(Agência Espanhola de Cooperação Internacional para o
Desenvolvimento-</FONT> <FONT COLOR="#ff0000">Agencia Española de
Cooperación Internacional para el Desarrollo</FONT><FONT COLOR="#000000">),
LAIF/EU (Latin America Investment Facility – European
Union-</FONT><FONT COLOR="#ff0000">Facilidad de Inversión para
America Latina</FONT><FONT COLOR="#000000">)  com a finalidade
educativa e  de promover o livre acesso a ferramentas para o projeto
de sistemas condominiais de esgoto com a utilização de técnicas
modernas de dimensionamento hidráulico.  O software Red Basica é
composto ainda de uma planilha de cálculo hidráulico, que
complementa o plugin, igualmente de livre.</FONT></P>
<H1 CLASS="western" STYLE="line-height: 150%"><BR><BR>
</H1>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<H1 CLASS="western" STYLE="line-height: 150%; page-break-before: always">
Funcionalidades</H1>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
O complemento mescla funções básicas já presentes no QGIS
(ferramentas de desenho, georreferenciamento, dentre outras) com
outras funcionalidades criadas com a finalidade de facilitar e
automatizar o projeto de uma rede coletora de esgoto.</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
As ferramentas adicionadas ao QGIS pelo complemento são:</P>
<UL>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Criação de
	camadas vetoriais (shapes) pré-configuradas para elaboração do
	projeto;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Nomeação
	dos coletores;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Vinculação
	entre as camadas vetoriais e seus atributos;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Estilos e
	rótulos personalizados para cada camada;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Checagem de
	eventuais inconsistências do projeto;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Janelas de
	exibição dos atributos do trecho selecionado e outras informações
	do projeto;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Exportação
	de dados do traçado realizado para cálculo hidráulico em planilha
	especialmente elaborada com essa finalidade (ou outro tipo de
	software externo de cálculo hidráulico);</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Importação
	dos resultados do cálculo hidráulico realizado externamente  de
	volta para o projeto;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Exibição
	do resultado do dimensionamento na planta de projeto;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Módulo de
	impressão do projeto.</P>
</UL>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Os dados são exportados do QGIS para um arquivo “.csv” contendo
informações básicas para o dimensionamento, como: nomeação dos
coletores, nomeação dos trechos, extensão de cada trecho,
tipologia do traçado , cotas do terrenos, anotações auxiliares
feitas pelo usuário durante o projeto, etc.</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<H1 CLASS="western" STYLE="line-height: 150%">Configurações
iniciais</H1>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Para a utilização do complemento RedBasica de forma correta, o
usuário deve seguir algumas recomendações:</P>
<UL>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Ao inserir
	uma nova camada deve-se informar o SRC que está sendo trabalhado;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Utilizar
	sempre um SRC de coordenadas planas, nunca geométricas;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Caso
	utilizada, a camada Raster de modelo digital do terreno deve estar
	no mesmo SRC da camada dos coletores;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Cada trecho
	pode receber em seu ponto de montante no máximo três coletores, ou
	seja, um trecho de montante do seu próprio coletor e mais dois
	outros coletores contribuindo nele;</P>
	<LI><P STYLE="margin-bottom: 0.14in; line-height: 150%">Para inserir
	novos coletores/trechos recomenda-se ao usuário desabilitar a opção
	“Suprimir janela de formulário de atributo após criação” que
	encontra-se em Configurações &gt; Opções&gt; Criação de
	feições.</P>
</UL>
<H1 CLASS="western" STYLE="line-height: 150%"><BR><BR>
</H1>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<H1 CLASS="western" STYLE="line-height: 150%; page-break-before: always">
Ferramentas</H1>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_c3e50749.png" NAME="Imagem 1" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Configurações básicas das camadas vetoriais (shapes) dos
trechos e dos dispositivos de inspeção. Esse botão permite ao
usuário escolher entre  utilizar um shapefile de traçado já
existente ou criar um novo. Além disso, permite escolher o nome das
camadas tanto dos trechos quanto dos Dispositivos de Inspeção e
seus respectivos atributos.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_c3c62e9b.png" NAME="Imagem 2" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Cria a shapefile e insere um nó em cada uma das extremidades de
um trecho. Cada nó representa um dispositivo de inspeção (Caixa de
Inspeção, Poço de Visita, Terminal de Limpeza, etc). Se o usuário
tiver disponível e indicar um arquivo raster contendo um modelo
digital do terreno essa função também captura automaticamente a
cota do terreno para cada extremidade dos trechos.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_6b9f5b66.png" NAME="Imagem 3" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Salva qualquer alteração que foi feita na camada vetorial dos
trechos, tanto no desenho quanto nos atributos. <BR><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
<IMG SRC="i_5822551b0bd548b5_html_648a204c.png" NAME="Imagem 4" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Utilizado como uma verificação da consistência do traçado
feito pelo usuário. Ao clicar no botão o QGIS selecionará todos os
trechos que não estão ligados em nenhum outro coletor, ou seja,
apenas os trechos finais do coletor devem ser selecionados, se
qualquer outro trecho for selecionado quer dizer que não há conexão
entre sua extremidade a jusante e o próximo coletor.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_f4a980a2.png" NAME="Imagem 5" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Insere uma camada vetorial estilizada para que o usuário nomeie
as quadras que fazem parte da área de interesse e indique quantas
unidades de contribuição (lotes, casas, etc) lançam com suas
vazões em algum trecho, tanto para inicio quanto para final do plano
do projeto.</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
<IMG SRC="i_5822551b0bd548b5_html_3da33496.png" NAME="Imagem 6" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - É um auxilio para o usuário poder ver com clareza para qual lado
está à declividade natural de cada quadra. É utilizado na fase
anterior ao traçado para indicar qual o ponto preferencial pelo qual
o coletor de esgoto deve passar em cada quadra. 
</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_4ba1168a.png" NAME="Imagem 7" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Também é um auxilio para o usuário. Serve para indicar os
pontos definidos pelo projetista onde obrigatoriamente os coletores
de esgoto devem passar, a  escolha pode ser para evitar grandes
profundidades, desviar de obstáculos, ruas asfaltadas, dentre
outras.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_4e7ae0d9.png" NAME="Imagem 8" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><IMG SRC="i_5822551b0bd548b5_html_734ccf04.png" NAME="Imagem 13" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Alterna o rótulo e estilo tanto das camadas vetoriais trechos
quanto de dispositivos de inspeção para o modo de traçado (edição)
e de visualização (plotagem, impressão).</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_bc5b6a96.png" NAME="Imagem 9" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Exporta os atributos de trechos e de dispositivos de inspeção
para um arquivo “.csv” que pode ser utilizado em uma planilha
auxiliar ou software de cálculos para dimensionar a rede coletora de
esgoto.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><BR><BR>
</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_dee2d20b.png" NAME="Imagem 14" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
 - Importa para a camadas vetorial do QGIS os atributos de cada
trecho que foram dimensionados externamente. Pode conter os
diâmetros, profundidades, cotas, declividades, verificações
hidráulicas, entre outras informações para cada trecho.</P>
<P STYLE="margin-bottom: 0.14in; line-height: 150%"><IMG SRC="i_5822551b0bd548b5_html_8ec6691b.png" NAME="Imagem 11" ALIGN=LEFT HSPACE=12 WIDTH=36 HEIGHT=36 BORDER=0><BR><BR>
</P>
<P STYLE="margin-left: 0.59in; text-indent: -0.59in; margin-bottom: 0.14in; line-height: 150%">
- Importa para a camadas vetorial do QGIS os atributos de cada
dispositivo de inspeção que foram dimensionados externamente. Por
exemplo, qual o órgão acessório utilizado, profundidades, cotas,
etc.</P>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<H1 CLASS="western" STYLE="line-height: 150%">Atributos padrão</H1>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
O usuário pode escolher entre utilizar uma camada vetorial já
existente (com um traçado de rede já feito) ou inserir uma nova e
realizar seu traçado utilizando as ferramentas de desenho do QGIS. 
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Ao escolher por inserir uma camada vetorial nova, ele escolhe o nome
e o complemento irá cria-la com seus atributos padrão, que estão
listados abaixo junto com suas respectivas funções:</P>
<P STYLE="text-indent: -0.79in; margin-bottom: 0.14in; line-height: 150%">
<IMG SRC="i_5822551b0bd548b5_html_70148cdb.png" NAME="Imagem 15" ALIGN=BOTTOM WIDTH=721 HEIGHT=374 BORDER=0></P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
A camada vetorial de nós que representa os dispositivos de inspeção
das duas extremidades de cada trecho são inseridas também com seus
atributos padrão, listados abaixo junto com suas respectivas
funções: 
</P>
<P STYLE="text-indent: -0.79in; margin-bottom: 0.14in"><IMG SRC="i_5822551b0bd548b5_html_c25209d1.png" NAME="Imagem 18" ALIGN=BOTTOM WIDTH=714 HEIGHT=117 BORDER=0></P>
<H1 CLASS="western" STYLE="line-height: 150%; page-break-before: always">
Colaboradores</H1>
<P STYLE="margin-bottom: 0.14in"><A NAME="_GoBack"></A><BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Modelagem Hidráulica: Leonardo Porto Nazareth</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Analista de Conceito: Leonardo Porto Nazareth</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
Analistas de Programação: Fábio Machado Rogerio e Sergio Yamani</P>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<H1 CLASS="western" STYLE="line-height: 150%; page-break-before: always">
Desenvolvedores</H1>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
O software foi desenvolvido pela Infinisoft© para a empresa
Diagonal© Transformação de Territórios.</P>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<P STYLE="margin-bottom: 0.14in"><BR><BR>
</P>
<P STYLE="text-indent: -0.79in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
<BR><BR>
</P>
<P STYLE="text-indent: 0.39in; margin-bottom: 0.14in; line-height: 150%">
 
</P>
</BODY>
</HTML>